# Run in a fresh PowerShell 7 process. Does not open the game or native mappings.
$ErrorActionPreference = 'Stop'
$source = Get-Content (Join-Path $PSScriptRoot '../VideoExport.Core/ScreenshotPlugins/ReshadeAPI.cs') -Raw
$stubs = @'
namespace UnityEngine {
    public enum TextureFormat { RGBA32 }
    public class Texture2D {
        public Texture2D(int w, int h, TextureFormat f, bool m, bool l) {}
        public void LoadRawTextureData(byte[] b) {}
        public void Apply() {}
    }
}
namespace VideoExport {
    public static class VideoExport { public static Log Logger = new Log(); }
    public class Log {
        public void LogWarning(string s) {}
        public void LogError(string s) {}
    }
}
public static class CaptureSizeTest {
    static void Assert(bool v, string message) {
        if (!v) throw new System.Exception(message);
    }
    public static string Run() {
        var t = typeof(VideoExport.ScreenshotPlugins.ReshadeAPI);
        var flags = System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static;
        var memory = System.Runtime.InteropServices.Marshal.AllocHGlobal(12);
        int w, h;
        try {
            Assert(!VideoExport.ScreenshotPlugins.ReshadeAPI.TryGetCaptureSize(out w, out h) && w == 0 && h == 0, "uninitialized");
            t.GetField("_initialized", flags).SetValue(null, true);
            t.GetField("_shmFile", flags).SetValue(null, new System.IntPtr(1));
            t.GetField("_shm", flags).SetValue(null, memory);
            System.Runtime.InteropServices.Marshal.WriteInt32(memory, 0, 3440);
            System.Runtime.InteropServices.Marshal.WriteInt32(memory, 4, 1440);
            System.Runtime.InteropServices.Marshal.WriteInt32(memory, 8, 4);
            Assert(VideoExport.ScreenshotPlugins.ReshadeAPI.TryGetCaptureSize(out w, out h) && w == 3440 && h == 1440, "actual capture dimensions");
            System.Runtime.InteropServices.Marshal.WriteInt32(memory, 0, 0);
            Assert(!VideoExport.ScreenshotPlugins.ReshadeAPI.TryGetCaptureSize(out w, out h) && w == 0 && h == 0, "zero width");
            System.Runtime.InteropServices.Marshal.WriteInt32(memory, 0, 3440);
            System.Runtime.InteropServices.Marshal.WriteInt32(memory, 8, 0);
            Assert(!VideoExport.ScreenshotPlugins.ReshadeAPI.TryGetCaptureSize(out w, out h), "zero channels");
            System.Runtime.InteropServices.Marshal.WriteInt32(memory, 8, 4);
            System.Runtime.InteropServices.Marshal.WriteInt32(memory, 4, -1);
            Assert(!VideoExport.ScreenshotPlugins.ReshadeAPI.TryGetCaptureSize(out w, out h) && w == 0 && h == 0, "overflow resets both outputs");
            return "PASS: 5 isolated capture-size cases (Unity/logger stubs; no native capture).";
        } finally {
            t.GetField("_initialized", flags).SetValue(null, false);
            t.GetField("_shmFile", flags).SetValue(null, System.IntPtr.Zero);
            t.GetField("_shm", flags).SetValue(null, System.IntPtr.Zero);
            System.Runtime.InteropServices.Marshal.FreeHGlobal(memory);
        }
    }
}
'@
Add-Type -TypeDefinition ($source + [Environment]::NewLine + $stubs)
[CaptureSizeTest]::Run()
